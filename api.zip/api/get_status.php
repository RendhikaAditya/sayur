<?php
require_once('koneksi.php');
$id = $_POST['idc'];

$query = mysqli_query($con, "SELECT * FROM `tbl_orders` WHERE `id_order`='$id'");

if (mysqli_num_rows($query) > 0) {
    $response = array();
    while ($x = mysqli_fetch_array($query)) {


        $h['id'] = $id;
        $h['status'] = $x['status_ord'];

        array_push($response, $h);
    }
    echo strip_tags(json_encode($response));
} else {
    $response["message"] = "tidak ada data";
    echo json_encode($response);
}
