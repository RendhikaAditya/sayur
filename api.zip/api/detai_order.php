<?php
require_once('koneksi.php');
$id = $_POST['ido'];

$query = mysqli_query($con, "SELECT * FROM `tbl_orders_detail` LEFT JOIN tbl_produk ON tbl_orders_detail.id_produk=tbl_produk.id_produk WHERE id_order='$id'");


if (mysqli_num_rows($query) > 0) {
    $response = array();
    while ($x = mysqli_fetch_array($query)) {


        $h['id'] = $x['id_produk'];
        $h['nama'] = $x['judul'];
        $h['harga'] = $x['harga'];
        $h['satuan'] = $x['berat'];
        $h['jumlah'] = $x['jml'];
        $h['stok'] = $x['stok'];
        $h['total'] = $x['jml'] * $x['harga'];
        $h['gambar'] = 'https://sayursegar.huqypropertisyariah.com/foto/produk/' . $x['foto'];

        array_push($response, $h);
    }
    echo strip_tags(json_encode($response));
} else {
    $response["message"] = "tidak ada data";
    echo json_encode($response);
}
