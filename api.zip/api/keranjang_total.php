<?php
require_once('koneksi.php');
class emp
{
}
$id = $_POST['id'];
$cek = mysqli_query($con, "SELECT * FROM `tbl_keranjang` LEFT JOIN tbl_produk ON tbl_keranjang.id_produk=tbl_produk.id_produk WHERE tbl_keranjang.id_customer=$id");
if (mysqli_num_rows($cek) > 0) {
    $response = array();

    while ($x = mysqli_fetch_array($cek)) {
        $stotal = 0;
        $harga = $x['harga'];
        $jumlah = $x['jml'];
        $stotal = $harga * $jumlah;
        $t = $stotal + $t;
    }
    $hasil = $hasil = $t;
    $response = new emp();
    $response->total =  $hasil;
    die(json_encode($response));
} else {
    $response["message"] = "tidak ada data";
    echo json_encode($response);
}
