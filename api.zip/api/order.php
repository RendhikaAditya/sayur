<?php
require_once('koneksi.php');
$id = $_POST['idc'];

$query = mysqli_query($con, "SELECT * FROM `tbl_orders` WHERE `tbl_orders`.`id_customer`='$id' ORDER BY `tbl_orders`.`id_order` DESC");

// $hasil  = mysqli_query($con, "SELECT * FROM `tbl_orders` LEFT JOIN `tbl_orders_detail` ON tbl_orders.id_order=tbl_orders_detail.id_order LEFT JOIN tbl_produk ON tbl_orders_detail.id_produk=tbl_produk.id_produk WHERE `tbl_orders`.`id_customer`='$id'");


// $banyak  = mysqli_query($con, "SELECT * FROM `tbl_orders` LEFT JOIN `tbl_orders_detail` ON tbl_orders.id_order=tbl_orders_detail.id_order LEFT JOIN tbl_produk ON tbl_orders_detail.id_produk=tbl_produk.id_produk WHERE `tbl_orders`.`id_order`='$id'");
// $banyakItem = mysqli_num_rows($hasil);

if (mysqli_num_rows($query) > 0) {
    $response = array();
    while ($x = mysqli_fetch_array($query)) {

        $idord = $x['id_order'];
        $h['idord'] = $x['id_order'];
        $h['status'] = $x['status_ord'];
        $h['total'] = $x['total'];
        $item = mysqli_query($con, "SELECT * FROM `tbl_orders_detail` LEFT JOIN tbl_produk ON tbl_orders_detail.id_produk=tbl_produk.id_produk WHERE id_order=$idord");
        $y = mysqli_fetch_array($item);
        $h['banyakitem'] = "" . mysqli_num_rows($item);
        $h['namaprod'] = $y['judul'];
        $h['jumlah'] = $y['jml'];
        $h['harga'] = $y['harga'];
        $h['gambar'] = 'https://sayursegar.huqypropertisyariah.com/foto/produk/' . $y['foto'];
        array_push($response, $h);
    }
    echo strip_tags(json_encode($response));
} else {
    $response["message"] = "tidak ada data";
    echo json_encode($response);
}
