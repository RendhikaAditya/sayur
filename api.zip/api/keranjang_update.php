<?php
require_once('koneksi.php');
class emp
{
}
$id = $_POST['id'];
$jml = $_POST['jml'];
$code = $_POST['code'];


$cek = mysqli_query($con, "SELECT * FROM `tbl_keranjang` WHERE `id_keranjang`=$id");
if ($cek) {
    if ($code == 1) {
        $x = mysqli_fetch_array($cek);
        $jumlah = $x['jml'];
        $hasil = $jumlah + 1;
        $query = mysqli_query($con, "UPDATE `tbl_keranjang` SET `jml`=$hasil WHERE `id_keranjang`=$id");
        if ($query) {
            $response = new emp();
            $response->response = "Tambah Berhasil di buat";
            $response->cod = 1;
            die(json_encode($response));
        } else {
            $response = new emp();
            $response->response = "Gagal! e";
            $response->cod = 0;
            die(json_encode($response));
        }
    } else if ($code == 2) {
        $x = mysqli_fetch_array($cek);
        $jumlah = $x['jml'];
        $hasil = $jumlah - 1;
        $query = mysqli_query($con, "UPDATE `tbl_keranjang` SET `jml`=$hasil WHERE `id_keranjang`=$id");
        if ($query) {
            $response = new emp();
            $response->response = "Kurang Berhasil";
            $response->cod = 1;
            die(json_encode($response));
        } else {
            $response = new emp();
            $response->response = "Gagal! ";
            $response->cod = 0;
            die(json_encode($response));
        }
    } else if ($code == 3) {
        $query = mysqli_query($con, "DELETE FROM `tbl_keranjang` WHERE `tbl_keranjang`.`id_keranjang` = $id");
        if ($query) {
            $response = new emp();
            $response->response = "Taggapan Berhasil di buat";
            $response->cod = 1;
            die(json_encode($response));
        } else {
            $response = new emp();
            $response->response = "Gagal Membuat! e";
            $response->cod = 0;
            die(json_encode($response));
        }
    }
}
mysqli_close($con);
