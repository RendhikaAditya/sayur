<?php
require_once('koneksi.php');
class emp
{
}

$id = $_POST['id'];

$hasil = mysqli_query($con, " SELECT * FROM `tbl_orders` WHERE id_order='$id'");
if (mysqli_num_rows($hasil) > 0) {
    $response = new emp();
    $x = mysqli_fetch_array($hasil);
    $response->total = $x['total'];
    die(json_encode($response));
} else {
    $response['message'] = 'tidak ada data';
    echo json_encode($response);
}
