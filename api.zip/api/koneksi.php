<?php
    define('HOST','localhost');
    define('USER','huqyprop_sayur');
    define('PASS','sayursegar123');
    define('DB','huqyprop_sayursegar');
    $con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');
?>