<?php
include_once "koneksi.php";

class emp
{
}

$id = $_POST['ido'];
$foto = $_POST['img'];
$harga = $_POST['harga'];

$tgl = date('Y-m-d');


$random = random_word(20);
$path = $random . ".png";
if ($foto == $id) {
    $queri = mysqli_query($con, "INSERT INTO `tbl_konfirmasi_bayar` (id_order,total_bayars,bukti,tgl_bayar) VALUES ('$id','$harga','noImage','$tgl')");
    // mysqli_query($con, "UPDATE `tbl_orders` SET `status_ord`='Segera Dikirim' WHERE `id_order`=$id");
} else {
    $query = mysqli_query($con, "INSERT INTO `tbl_konfirmasi_bayar` (id_order,total_bayars,bukti,tgl_bayar) VALUES ('$id','$harga','$path','$tgl')");
    // mysqli_query($con, "UPDATE `tbl_orders` SET `status_ord`='Menunggu Konfirmasi' WHERE `id_order`=$id");
}


if ($query) {

    file_put_contents("../foto/bukti/" . $random . ".png", base64_decode($foto));

    $response = new emp();
    $response->success = 1;
    $response->message = "Sukses konfirmasi";

    mysqli_query($con, "INSERT INTO `tbl_status_orders` (`id_order`,`status_order`,`tgl_status`) VALUES ('$id','DI PROSES','$tgl')");

    mysqli_query($con, "UPDATE `tbl_orders` SET `status_ord`='Menunggu Konfirmasi' WHERE `id_order`=$id");
    die(json_encode($response));
} else {
    $response = new emp();
    $response->success = 1;
    $response->message = "Sukses konfirmasi COD";
    die(json_encode($response));
}



function random_word($id = 20)
{
    $pool = '1234567890abcdefghijkmnpqrstuvwxyz';

    $word = '';
    for ($i = 0; $i < $id; $i++) {
        $word .= substr($pool, mt_rand(0, strlen($pool) - 1), 1);
    }
    return $word;
}



mysqli_close($con);
