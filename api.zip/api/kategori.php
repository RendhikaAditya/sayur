<?php
require_once('koneksi.php');

$query = "select * from tbl_kategori";
$hasil  = mysqli_query($con, $query);


if (mysqli_num_rows($hasil) > 0) {
  $response = array();
  while ($x = mysqli_fetch_array($hasil)) {
    $h['id'] = $x["id_kategori"];
    $h['nama'] = $x["nama_kategori"];
    $h['icon'] = "https://sayursegar.huqypropertisyariah.com/img/kategori/" . $x["icon_kategori"];
    array_push($response, $h);
  }
  echo json_encode($response);
} else {
  $response["message"] = "tidak ada data";
  echo json_encode($response);
}
