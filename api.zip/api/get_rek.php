<?php
require_once('koneksi.php');
class emp
{
}

// $id = $_POST['id'];

$hasil = mysqli_query($con, " SELECT * FROM `tbl_bank` WHERE id_bank=2");
if (mysqli_num_rows($hasil) > 0) {
    $response = new emp();
    $x = mysqli_fetch_array($hasil);
    $response->nomr = $x['no_rek'];
    $response->nama = $x['atas_nama'];
    die(json_encode($response));
} else {
    $response['message'] = 'tidak ada data';
    echo json_encode($response);
}
