<?php
require_once('koneksi.php');
// $id = $_GET['info_id'];
$query = "SELECT * FROM tbl_produk WHERE id_kategori=9 ORDER BY `tbl_produk`.`stok` DESC";
// LEFT JOIN tbl_kategori ON 'tb_produk.id_kategori'='tb_kategori.id_kategori'
$hasil  = mysqli_query($con, $query);



if (mysqli_num_rows($hasil) > 0) {
  $response = array();
  while ($x = mysqli_fetch_array($hasil)) {
    $h['id'] = $x['id_produk'];
    $h['nama'] = $x['judul'];
    $h['harga'] = $x['harga'];
    $h['satuan'] = $x['berat'];
    $h['stok'] = $x['stok'];
    $idk = $x['id_kategori'];
    $kat = "Select * FROM tbl_kategori where id_kategori=$idk";
    $skat = mysqli_query($con, $kat);
    $z = mysqli_fetch_array($skat);
    $h['kategori'] = $z['nama_kategori'];

    $h['gambar'] = 'https://sayursegar.huqypropertisyariah.com/foto/produk/' . $x['foto'];

    // $h['keterangan'] = $x['info_keterangan'];  
    // $h['telpon'] = $x['frn_telpon'];
    // $h['web'] = $x['frn_web'];
    // $h['email'] = $x['frn_email'];



    array_push($response, $h);
  }
  echo strip_tags(json_encode($response));
} else {
  $response["message"] = "tidak ada data";
  echo json_encode($response);
}
