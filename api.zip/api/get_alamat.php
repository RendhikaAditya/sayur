<?php
require_once('koneksi.php');

$id = $_POST['id'];
$cod = $_POST['cod'];

$cek = mysqli_query($con, "SELECT * FROM `tbl_alamat` WHERE `id_customer`='$id'");

$response = array();
if (mysqli_num_rows($cek) > 0) {
    if ($cod == 2) {
        while ($x = mysqli_fetch_array($cek)) {
            $h['nama'] = $x['namaal'];
            $h['pos'] = $x['kodepos'];
            $h['alamat'] = $x['alamat'];
            array_push($response, $h);
        }
        echo strip_tags(json_encode($response));
    } else {
        while ($x = mysqli_fetch_array($cek)) {
            $h['nama'] = $x['namaal'];
            $cuk = mysqli_query($con, "SELECT * FROM `tbl_customer` WHERE `id_customer`='$id'");
            $z = mysqli_fetch_array($cuk);
            $h['alamat'] = $x['alamat'] . " | No Telpon : " . $z['nohp'];
            array_push($response, $h);
        }
        echo strip_tags(json_encode($response));
    }
}
