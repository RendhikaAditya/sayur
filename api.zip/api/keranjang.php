<?php
require_once('koneksi.php');
class emp
{
}
$idp = $_POST['idP'];
$idc = $_POST['idC'];
$jml = $_POST['jml'];
// 	$tgl = date('d M Y');

$cek = mysqli_query($con, "SELECT * FROM `tbl_keranjang` WHERE `id_produk`=$idp AND `id_customer`=$idc");
if (mysqli_num_rows($cek) > 0) {
    $x = mysqli_fetch_array($cek);
    $jumlah = $x['jml'];
    $idk = $x['id_keranjang'];
    $hasil = $jumlah + $jml;
    $query = mysqli_query($con, "UPDATE `tbl_keranjang` SET `jml`=$hasil WHERE `id_keranjang`=$idk");
    if ($query) {
        $response = new emp();
        $response->response = "Taggapan Berhasil di buat";
        $response->code = 1;
        die(json_encode($response));
    } else {
        $response = new emp();
        $response->response = "Gagal Membuat! e";
        $response->code = 0;
        die(json_encode($response));
    }
    // UPDATE Customers SET ContactName='Juan' WHERE Country='Mexico';
} else {
    $query = mysqli_query($con, "INSERT INTO `tbl_keranjang` (`id_produk`, `id_customer`,`jml`) VALUES ('$idp', '$idc','$jml')");
    if ($query) {
        $response = new emp();
        $response->response = "Taggapan Berhasil di buat";
        $response->code = 1;
        die(json_encode($response));
    } else {
        $response = new emp();
        $response->response = "Gagal Membuat! a";
        $response->code = 0;
        die(json_encode($response));
    }
}

mysqli_close($con);
