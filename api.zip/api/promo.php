<?php
require_once('koneksi.php');
$id = $_POST['id_promo'];
$query = "select * from tb_promo where id_promo=$id";
$hasil  = mysqli_query($con, $query);


if (mysqli_num_rows($hasil) > 0) {
  $response = array();
  while ($x = mysqli_fetch_array($hasil)) {
    $h['id'] = $x["id_promo"];
    $h['foto'] = "https://sayursegar.huqypropertisyariah.com/foto/promo/" . $x["gambar_promo"];
    array_push($response, $h);
  }
  echo json_encode($response);
} else {
  $response["message"] = "tidak ada data";
  echo json_encode($response);
}
