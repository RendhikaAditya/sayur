<?php
require_once('koneksi.php');
class emp
{
}
$id = $_POST['id'];
$nama = $_POST['nama'];
$pos = $_POST['pos'];
$alamat = $_POST['alamat'];

$cek = mysqli_num_rows(mysqli_query($con, "SELECT * FROM `tbl_alamat` WHERE `id_customer`='$id'"));
if ($cek != 0) {
    $query = mysqli_query($con, "UPDATE `tbl_alamat` SET `namaal`='$nama', `kodepos`='$pos', `alamat`='$alamat' WHERE `id_customer`='$id'");
    if ($query) {
        $response = new emp();
        $response->response = "Edit Alamat Berhasil di buat";
        $response->cod = 1;
        die(json_encode($response));
    } else {
        $response = new emp();
        $response->response = "Gagal! Tambah Alamat";
        $response->cod = 0;
        die(json_encode($response));
    }
} else {
    $query = mysqli_query($con, "INSERT INTO `tbl_alamat` (id_customer, namaal, id_prov, id_kota, kodepos, alamat) VALUES ('$id', '$nama' ,'0' ,'0' , '$pos','$alamat')");
    if ($query) {
        $response = new emp();
        $response->response = "Tambah Alamat Berhasil";
        $response->cod = 1;
        die(json_encode($response));
    } else {
        $response = new emp();
        $response->response = "Gagal! Mengedit Alamat";
        $response->cod = 0;
        die(json_encode($response));
    }
}
