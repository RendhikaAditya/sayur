<?php
require_once('koneksi.php');
$id = $_POST['id_user'];
$sql = "SELECT * FROM `tbl_customer` LEFT JOIN tbl_alamat ON tbl_customer.id_customer=tbl_alamat.id_customer WHERE tbl_customer.id_customer=$id";
$query = mysqli_query($con, $sql);
$response = array();

if (mysqli_num_rows($query) > 0) {
  while ($x = mysqli_fetch_array($query)) {
    $h['id_user'] = $x['id_customer'];
    $h['nama'] = $x['nama_lengkap'];
    $h['no'] = $x['nohp'];
    $h['mail'] = $x['email'];
    $h['alamat'] = $x['alamat'];
    $h['pass'] = $x['password'];
    $h['foto'] = "https://sayursegar.huqypropertisyariah.com/foto/customer/defaultt.jpg";
    array_push($response, $h);
  }
  echo strip_tags(json_encode($response));
} else {
  $response["message"] = "tidak ada data";
  echo json_encode($response);
}
