<?php
include_once "koneksi.php";

class emp
{
}

$nama = $_POST['nama'];
$id = $_POST['idc'];
// $username =$_POST['frn_username'];
$password = $_POST['password'];
$telpon = $_POST['notelp'];
$email = $_POST['email'];
$tgl = date('d-m-y');
// $foto = $_POST['foto'];
$def = "default.jpg";


$query = mysqli_query($con, "UPDATE tbl_customer SET email='$email', password='$password', nama_lengkap='$nama', nohp='$telpon' WHERE id_customer='$id'");

if ($query) {

    $response = new emp();
    $response->success = 1;
    $response->message = "Sukses edit!";
    die(json_encode($response));
} else {
    $response = new emp();
    $response->success = 0;
    $response->message = "GAgal edit";
    die(json_encode($response));
}





mysqli_close($con);
