<?php
include_once "koneksi.php";

class emp
{
}

$id = $_POST['idu'];
$foto = $_POST['img'];


$random = random_word(20);
$path = $random . ".png";

$query = mysqli_query($con, "UPDATE `tbl_customer` SET `fotoregis`='$path' WHERE `email`='$id'");
$getid = mysqli_query($con, "SELECT * FROM `tbl_customer` WHERE `email`='$id'");
$x = mysqli_fetch_array($getid);

if ($query) {

    file_put_contents("../foto/customer/" . $random . ".png", base64_decode($foto));

    $response = new emp();
    $response->success = 1;
    $response->message = "Sukses konfirmasi";
    $response->idc = $x['id_customer'];


    die(json_encode($response));
} else {
    $response = new emp();
    $response->success = 0;
    $response->message = "GAgal";
    die(json_encode($response));
}



function random_word($id = 20)
{
    $pool = '1234567890abcdefghijkmnpqrstuvwxyz';

    $word = '';
    for ($i = 0; $i < $id; $i++) {
        $word .= substr($pool, mt_rand(0, strlen($pool) - 1), 1);
    }
    return $word;
}



mysqli_close($con);
