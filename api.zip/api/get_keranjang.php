<?php
require_once('koneksi.php');
$id = $_POST['idc'];

$query = "SELECT * FROM `tbl_keranjang` LEFT JOIN tbl_customer ON tbl_keranjang.id_customer=tbl_customer.id_customer LEFT JOIN tbl_produk ON tbl_keranjang.id_produk=tbl_produk.id_produk WHERE tbl_keranjang.`id_customer`=$id";
$hasil  = mysqli_query($con, $query);



  $response = array();
  while ($x = mysqli_fetch_array($hasil)) {
    $h['id'] = $x['id_keranjang'];
    $h['nama'] = $x['judul'];
    $h['harga'] = $x['harga'];
    $h['satuan'] = $x['berat'];
    $h['jumlah'] = $x['jml'];
    $h['total'] = $x['jml'] * $x['harga'];
    $h['stok'] = $x['stok'];
    $h['gambar'] = 'https://sayursegar.huqypropertisyariah.com/foto/produk/' . $x['foto'];

    // $h['keterangan'] = $x['info_keterangan'];  
    // $h['telpon'] = $x['frn_telpon'];
    // $h['web'] = $x['frn_web'];
    // $h['email'] = $x['frn_email'];



    array_push($response, $h);
  }
  echo strip_tags(json_encode($response));
