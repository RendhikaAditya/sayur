<?php
require_once('koneksi.php');
class emp
{
}


$id = $_POST['id'];
$total = $_POST['total'];
$metode = $_POST['metode'];
if ($metode == "COD") {
    $status = "Segera Dikirim";
} else {
    $status = "Pembayaran Tertunda";
}
$tgl = date('Ymd');
$jam = date('His');
$idO = date('dmy'). rand(0, 999);

$ambil = mysqli_query($con, "SELECT * FROM `tbl_alamat` WHERE id_customer='$id'");
if ($ambil) {
    $x = mysqli_fetch_array($ambil);
    $nama = $x['namaal'];
    $pos = $x['kodepos'];
    $alamat = $x['alamat'];
}


$query = mysqli_query($con, "INSERT INTO tbl_orders (id_order, status_ord, tgl_order, jam_order, id_customer, kurir, service, ongkir, total, expired, id_prov, id_kota, kodepos, alamat_o, nmpenerima, jmlberat, no_res) VALUES ('$idO', '$status', '$tgl', '$jam', '$id','$metode', ' ', '0', '$total','0', '0','0', '$pos', '$alamat', '$nama','0',' ')");
if ($query) {
    $response = new emp();
    $response->response = "Pesanan Berhasil di buat";
    $response->ido = $idO;
    $kranjang = mysqli_query($con, "SELECT * FROM `tbl_keranjang` WHERE `id_customer`='$id'");
    while ($q = mysqli_fetch_array($kranjang)) {
        $idp = $q['id_produk'];
        $jml = $q['jml'];
        mysqli_query($con, "INSERT INTO `tbl_orders_detail` (`id_order`, `id_produk`, `jml`) VALUES ('$idO', '$idp', '$jml')");
        $stok = mysqli_query($con, "SELECT * FROM `tbl_produk` WHERE id_produk='$idp'");
        $s = mysqli_fetch_array($stok);
        $stokA = $s['stok'];
        $stokj = $stokA - $jml;
        $terjual = $s['terjual'] + $jml;
        mysqli_query($con, "UPDATE `tbl_produk` SET `stok`='$stokj', `terjual`='$terjual' WHERE `id_produk`='$idp'");
    }
    mysqli_query($con, "DELETE FROM `tbl_keranjang` WHERE `tbl_keranjang`.`id_customer` = $id");


    $response->cod = 1;
    die(json_encode($response));
} else {
    $response = new emp();
    $response->response = $idO."Gagal! Membuat Pesanan";
    $response->cod = 0;
    die(json_encode($response));
}
