<?php
include_once "koneksi.php";

class emp
{
}

$nama = $_POST['nama'];
// $username =$_POST['frn_username'];
$password = $_POST['password'];
$telpon = $_POST['notelp'];
$email = $_POST['email'];
$tgl = date('y-m-d');
// $foto = $_POST['foto'];
$def = "default.jpg";

$num_rows = mysqli_num_rows(mysqli_query($con, "SELECT * FROM tbl_customer WHERE email='$email'"));

if ($num_rows == 0) {


    $query = mysqli_query($con, "INSERT INTO tbl_customer (email, password, nama_lengkap, nohp, tgl_daftar) VALUES ('$email', '$password', '$nama', '$telpon', '$tgl')");
    $ini = mysqli_query($con, "SELECT * FROM `tbl_customer` ORDER BY id_customer DESC LIMIT 1");
    $x = mysqli_fetch_array($ini);
    $i = $x['id_customer'];

    if ($query) {

        $response = new emp();
        $response->success = 1;
        $response->message = "Sukses mendaftar!";
        $response->idc=$i;
        die(json_encode($response));
    } else {
        $response = new emp();
        $response->success = 0;
        $response->message = "GAgal";
        die(json_encode($response));
    }
} else {
    $response = new emp();
    $response->success = 0;
    $response->message = "Username sudah terdaftar";
    die(json_encode($response));
}





mysqli_close($con);
